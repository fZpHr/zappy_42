using System;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;

public class NetworkManager : MonoBehaviour
{
    public string serverIP = "127.0.0.1";  // Adresse du serveur
    public int serverPort = 4244;  // Port du serveur
    public float refreshInterval = 1.0f;  // Intervalle pour recevoir les données

    private TcpClient client;
    private NetworkStream stream;
    private Thread receiveThread;
    private string latestMapData;

    void Start()
    {
        ConnectToServer();
    }

    void ConnectToServer()
    {
        try
        {
            client = new TcpClient();
            client.Connect(serverIP, serverPort);
            stream = client.GetStream();

            // Démarre le thread pour recevoir les données en continu
            receiveThread = new Thread(new ThreadStart(ReceiveData));
            receiveThread.IsBackground = true;
            receiveThread.Start();
            Debug.Log("Connecté au serveur");
        }
        catch (Exception ex)
        {
            Debug.LogError("Erreur de connexion : " + ex.Message);
        }
    }

    void ReceiveData()
    {
        byte[] buffer = new byte[4096];
        try
        {
            while (client.Connected)
            {
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                if (bytesRead > 0)
                {
                    string dataReceived = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Debug.Log("Données reçues : " + dataReceived);

                    // Mettez à jour la carte avec les données reçues
                    latestMapData = dataReceived;

                    // Vous pouvez maintenant utiliser `latestMapData` pour créer ou mettre à jour la carte en 3D
                    UpdateMap(latestMapData);
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("Erreur lors de la réception des données : " + ex.Message);
        }
    }

    void UpdateMap(string mapData)
    {
        // Ici, vous pouvez ajouter la logique pour analyser les données de la carte et mettre à jour la scène Unity.
        // Par exemple, vous pouvez transformer chaque caractère en un élément de la carte (ex. un cube ou un sprite).
        Debug.Log("Mise à jour de la carte avec les nouvelles données.");
    }

    void OnApplicationQuit()
    {
        if (receiveThread != null)
            receiveThread.Abort();
        if (stream != null)
            stream.Close();
        if (client != null)
            client.Close();
    }

    public string GetLatestMapData()
    {
        return latestMapData;
    }
}

// using System;
// using System.Net.Sockets;
// using UnityEngine;

// public class TestPortConnection : MonoBehaviour
// {
//     private string serverAddress = "127.0.0.1";  // Adresse du serveur
//     private int port = 4244;  // Port que vous souhaitez tester

//     void Start()
//     {
//         TestPort(serverAddress, port);
//     }

//     // Tester la connectivité sur un port
//     void TestPort(string server, int port)
//     {
//         try
//         {
//             Debug.Log("Tentative de connexion au serveur " + server + " sur le port " + port);

//             TcpClient tcpClient = new TcpClient();
//             tcpClient.Connect(server, port);  // Essaye de se connecter au serveur et au port spécifiés

//             Debug.Log("Connexion réussie à " + server + " sur le port " + port);

//             tcpClient.Close();  // Ferme la connexion
//         }
//         catch (Exception e)
//         {
//             Debug.LogError("Erreur de connexion au port : " + e.Message);
//         }
//     }
// }
